# Expense Tracker — Android build notes

The bundled logo is optional at runtime. If it cannot be loaded, the app continues without the logo.

Logo: `assets/finance_logo.svg`

The logo path is resolved relative to the application directory, not the current working directory.
