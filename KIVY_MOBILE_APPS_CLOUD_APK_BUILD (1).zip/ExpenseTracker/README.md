# Expense Tracker — date-based CSV and shared mentions

The app uses the transaction date as the CSV filename:

- `2026-10-05` → `20261005.csv`
- `2026-10-06` → `20261006.csv`

Files are stored under `/storage/emulated/0/ExpenseData`.

## Date behavior

**Add:** a transaction is saved to the CSV for its entered date. If that date has no CSV yet, the file is created automatically.

**Update:** if the date is changed, the transaction is removed from the old date's CSV and appended to the destination date's CSV.

**New Date:** selects the CSV corresponding to the date. It does not create an empty file until a record is saved.

## mentions.yaml

`mentions.yaml` is loaded from the application directory and contains the preloaded mentions from the @Mention Manager:

```yaml
mentions:
  - "@rabbi"
  - "@sbi"
  - "@ebay"
  - "@Amazon"
  - "@flipkart"
  - "@swiggy"
  - "@zomato"
```

The Description field has an @mention selector. Manually typed valid mentions are also automatically added to `mentions.yaml`.

## Run

```bash
pip install -r requirements.txt
python main.py
```

For Android, package with Buildozer and include `python3,kivy,pyyaml` in requirements.
