import os,csv,re
from collections import defaultdict
from datetime import datetime
import yaml
from kivy.app import App
from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.scrollview import ScrollView
from kivy.uix.label import Label
from kivy.uix.image import Image
from kivy.uix.textinput import TextInput
from kivy.uix.spinner import Spinner
from kivy.uix.button import Button
from kivy.uix.popup import Popup
from kivy.uix.filechooser import FileChooserListView

BASE_DIR='/storage/emulated/0/ExpenseData'
APP_DIR=os.path.dirname(os.path.abspath(__file__))
MENTIONS_FILE=os.path.join(APP_DIR,'mentions.yaml')
os.makedirs(BASE_DIR,exist_ok=True)
FIELDS=['Date','Type','Category','Description','Amount']
CATEGORIES={'Needs':['Housing Expenses','Food Expenses','Transportation','Medical','Education','EMI / Loans'],'Wants':['Travel','Entertainment','Shopping','Personal Care','Puja','Subscriptions','Utility Expenses'],'Savings':['Savings','Insurance','Piggybank','Coinsaved'],'Misc':['Giving','Miscellaneous','Servant'],'INCOMES':['Salary','Business','Freelance','Rent','Interest','Pension','Other']}
DEFAULT_MENTIONS=['@rabbi','@sbi','@ebay','@Amazon','@flipkart','@swiggy','@zomato']
MENTION_RE=re.compile(r'@[A-Za-z0-9_][A-Za-z0-9_.-]*')

class MentionManager:
    def __init__(self,path): self.path=path; self.mentions=[]; self.load()
    @staticmethod
    def norm(v):
        v=str(v).strip(); return '' if not v else (v if v.startswith('@') else '@'+v)
    def load(self):
        try:
            with open(self.path,encoding='utf-8') as f: data=yaml.safe_load(f) or {}
            vals=data.get('mentions',[]); seen=set(); self.mentions=[]
            for v in vals if isinstance(vals,list) else []:
                m=self.norm(v)
                if MENTION_RE.fullmatch(m) and m.casefold() not in seen: self.mentions.append(m); seen.add(m.casefold())
            if not self.mentions: self.mentions=DEFAULT_MENTIONS[:]
        except Exception: self.mentions=DEFAULT_MENTIONS[:]; self.save()
    def save(self):
        with open(self.path,'w',encoding='utf-8') as f: yaml.safe_dump({'mentions':self.mentions},f,allow_unicode=True,sort_keys=False)
    def add_if_missing(self,m):
        m=self.norm(m)
        if MENTION_RE.fullmatch(m) and m.casefold() not in {x.casefold() for x in self.mentions}: self.mentions.append(m); self.save()

class MainLayout(BoxLayout):
    def build_logo_header(self, title_text, subtitle_text=""):
        header = BoxLayout(orientation="horizontal", size_hint_y=None, height=dp(70), spacing=dp(10))
        logo_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets", "finance_logo.png")
        if os.path.exists(logo_path):
            header.add_widget(Image(source=logo_path, size_hint=(None, 1), width=dp(60), keep_ratio=True, allow_stretch=True))
        text_box = BoxLayout(orientation="vertical", spacing=dp(1))
        text_box.add_widget(Label(text=title_text, font_size="24sp", bold=True, halign="left", valign="middle"))
        if subtitle_text:
            text_box.add_widget(Label(text=subtitle_text, font_size="12sp", halign="left", valign="middle"))
        header.add_widget(text_box)
        return header

    def __init__(self,**kw):
        super().__init__(orientation='vertical',padding=dp(10),spacing=dp(10),**kw)
        self.category_map={}; self.records=[]; self.current_record=-1; self.loaded_file=None
        self.mention_manager=MentionManager(MENTIONS_FILE); self.build_ui()
    @staticmethod
    def normalize_date(v):
        try:return datetime.strptime(v.strip(),'%Y-%m-%d').strftime('%Y-%m-%d')
        except ValueError: raise ValueError('Date must be YYYY-MM-DD.')
    @classmethod
    def filename_for_date(cls,v): return datetime.strptime(cls.normalize_date(v),'%Y-%m-%d').strftime('%Y%m%d')+'.csv'
    def path_for_date(self,v): return os.path.join(BASE_DIR,self.filename_for_date(v))
    def create_row(self,title,w):
        row=BoxLayout(orientation='vertical',size_hint_y=None,height=dp(30)+w.height+dp(5),spacing=dp(5)); lab=Label(text=title,size_hint_y=None,height=dp(25),halign='left',valign='middle'); lab.bind(size=lab.setter('text_size')); row.add_widget(lab); row.add_widget(w); return row
    def build_ui(self):
        self.add_widget(self.build_logo_header('Expense Tracker','Date-based CSV transactions')); scroll=ScrollView(); c=BoxLayout(orientation='vertical',spacing=dp(10),padding=dp(10),size_hint_y=None); c.bind(minimum_height=c.setter('height'))
        self.date_input=TextInput(text=datetime.today().strftime('%Y-%m-%d'),multiline=False,size_hint_y=None,height=dp(50)); c.add_widget(self.create_row('Date',self.date_input))
        cats=[]
        for typ,vals in CATEGORIES.items():
            for cat in vals: cats.append(cat); self.category_map[cat]=typ
        self.category_spinner=Spinner(text='Select Category',values=cats,size_hint_y=None,height=dp(50)); self.category_spinner.bind(text=self.update_ntype); c.add_widget(self.create_row('Category',self.category_spinner))
        self.ntype_label=Label(text='',size_hint_y=None,height=dp(40),color=(0,1,1,1)); c.add_widget(self.create_row('Type',self.ntype_label))
        db=BoxLayout(orientation='vertical',size_hint_y=None,height=dp(95),spacing=dp(3)); self.desc_input=TextInput(multiline=False,size_hint_y=None,height=dp(50)); db.add_widget(self.desc_input); self.mention_spinner=Spinner(text='Select @mention',values=['Select @mention']+self.mention_manager.mentions,size_hint_y=None,height=dp(38)); self.mention_spinner.bind(text=self.insert_mention); db.add_widget(self.mention_spinner); c.add_widget(self.create_row('Description / @mention',db))
        self.amount_input=TextInput(multiline=False,input_filter='float',size_hint_y=None,height=dp(50)); c.add_widget(self.create_row('Amount',self.amount_input))
        self.record_label=Label(text='0 / 0',size_hint_y=None,height=dp(40),color=(1,1,0,1)); c.add_widget(self.record_label); self.file_label=Label(text='CSV: no file selected',size_hint_y=None,height=dp(40),font_size='13sp'); c.add_widget(self.file_label)
        self.total_label=Label(text='₹ 0.00',size_hint_y=None,height=dp(40),font_size='20sp',color=(0,1,0,1),bold=True); c.add_widget(self.create_row('Daily Total',self.total_label))
        self.mention_label=Label(text='No mentions',markup=True,size_hint_y=None,height=dp(150),halign='left',valign='top'); self.mention_label.bind(size=self.mention_label.setter('text_size')); c.add_widget(self.create_row('@ Mention Totals',self.mention_label))
        fg=GridLayout(cols=3,size_hint_y=None,height=dp(60),spacing=dp(5));
        for text,cb in [('Browse CSV',self.browse_csv),('Save Current Date',self.save_all_records),('New Date',self.new_date_file)]:
            b=Button(text=text); b.bind(on_press=cb); fg.add_widget(b)
        c.add_widget(fg); nav=GridLayout(cols=4,size_hint_y=None,height=dp(60),spacing=dp(5))
        for text,cb in [('|<',self.first_record),('<',self.prev_record),('>',self.next_record),('>|',self.last_record)]: b=Button(text=text); b.bind(on_press=cb); nav.add_widget(b)
        c.add_widget(nav); act=GridLayout(cols=3,size_hint_y=None,height=dp(60),spacing=dp(5))
        for text,cb in [('Add',self.add_record),('Update',self.update_record),('Delete',self.delete_record)]: b=Button(text=text); b.bind(on_press=cb); act.add_widget(b)
        c.add_widget(act); scroll.add_widget(c); self.add_widget(scroll)
    def update_ntype(self,s,text): self.ntype_label.text=self.category_map.get(text,'')
    def show_popup(self,title,msg): Popup(title=title,content=Label(text=msg),size_hint=(.8,.4)).open()
    def insert_mention(self,s,text):
        if text=='Select @mention': return
        cur=self.desc_input.text.strip(); self.desc_input.text=(cur+' ' if cur else '')+text; self.mention_spinner.text='Select @mention'; self.refresh_totals()
    def refresh_mention_spinner(self): self.mention_spinner.values=['Select @mention']+self.mention_manager.mentions
    def browse_csv(self,inst):
        chooser=FileChooserListView(path=BASE_DIR,filters=['*.csv']); pop=Popup(title='Select CSV',content=chooser,size_hint=(.95,.95))
        def selected(obj,val):
            if val: pop.dismiss(); self.load_csv(val[0])
        chooser.bind(selection=selected); pop.open()
    def read_csv_file(self,path):
        if not os.path.exists(path): return []
        with open(path,newline='',encoding='utf-8') as f:
            return [{'Date':r.get('Date',''),'Type':r.get('Type',r.get('nType','')),'Category':r.get('Category',''),'Description':r.get('Description',''),'Amount':r.get('Amount','')} for r in csv.DictReader(f)]
    def write_csv_file(self,path,records):
        os.makedirs(os.path.dirname(path),exist_ok=True)
        with open(path,'w',newline='',encoding='utf-8') as f: w=csv.DictWriter(f,fieldnames=FIELDS); w.writeheader(); w.writerows(records)
    def load_csv(self,path):
        self.loaded_file=path; self.records=self.read_csv_file(path); self.current_record=0 if self.records else -1
        if self.records:self.show_record()
        self.file_label.text='CSV: '+os.path.basename(path); self.refresh_totals()
    def show_record(self):
        if not self.records:return
        r=self.records[self.current_record]; self.date_input.text=r['Date']; self.category_spinner.text=r['Category']; self.ntype_label.text=r['Type']; self.desc_input.text=r['Description']; self.amount_input.text=r['Amount']; self.record_label.text=f'{self.current_record+1} / {len(self.records)}'
    def first_record(self,i):
        if self.records:self.current_record=0; self.show_record()
    def prev_record(self,i):
        if self.records and self.current_record>0:self.current_record-=1; self.show_record()
    def next_record(self,i):
        if self.records and self.current_record<len(self.records)-1:self.current_record+=1; self.show_record()
    def last_record(self,i):
        if self.records:self.current_record=len(self.records)-1; self.show_record()
    def extract_mentions(self,text): return re.findall(r'@[A-Za-z0-9_][A-Za-z0-9_.-]*',text or '')
    def read_form(self):
        date=self.normalize_date(self.date_input.text); cat=self.category_spinner.text
        if cat=='Select Category': raise ValueError('Select a category.')
        if not self.ntype_label.text: raise ValueError('Category type is missing.')
        desc=self.desc_input.text.strip(); amount=self.amount_input.text.strip()
        if not desc: raise ValueError('Enter a description.')
        try: float(amount)
        except ValueError: raise ValueError('Amount must be numeric.')
        for m in self.extract_mentions(desc): self.mention_manager.add_if_missing(m)
        self.refresh_mention_spinner(); return {'Date':date,'Type':self.ntype_label.text,'Category':cat,'Description':desc,'Amount':amount}
    def add_record(self,i):
        try:r=self.read_form()
        except ValueError as e:self.show_popup('Invalid record',str(e)); return
        target=self.path_for_date(r['Date'])
        if self.loaded_file and os.path.abspath(target)!=os.path.abspath(self.loaded_file): self.write_csv_file(self.loaded_file,self.records); self.loaded_file=target; self.records=self.read_csv_file(target)
        else:self.loaded_file=target
        self.records.append(r); self.current_record=len(self.records)-1; self.write_csv_file(target,self.records); self.show_record(); self.refresh_totals(); self.file_label.text='CSV: '+os.path.basename(target)
    def update_record(self,i):
        if self.current_record<0:return
        try:new=self.read_form()
        except ValueError as e:self.show_popup('Invalid record',str(e)); return
        oldfile=self.loaded_file; oldidx=self.current_record; newfile=self.path_for_date(new['Date'])
        if not oldfile or os.path.abspath(oldfile)==os.path.abspath(newfile):
            self.records[oldidx]=new; self.loaded_file=newfile; self.write_csv_file(newfile,self.records)
        else:
            del self.records[oldidx]; self.write_csv_file(oldfile,self.records); dest=self.read_csv_file(newfile); dest.append(new); self.records=dest; self.loaded_file=newfile
            self.current_record=len(dest)-1
        self.show_record(); self.refresh_totals(); self.file_label.text='CSV: '+os.path.basename(self.loaded_file); self.show_popup('Saved','Record saved to '+os.path.basename(self.loaded_file))
    def delete_record(self,i):
        if self.current_record<0 or not self.loaded_file:return
        del self.records[self.current_record]; self.write_csv_file(self.loaded_file,self.records)
        if self.records:self.current_record=min(self.current_record,len(self.records)-1); self.show_record()
        else:self.current_record=-1; self.record_label.text='0 / 0'
        self.refresh_totals()
    def new_date_file(self,i):
        try:d=self.normalize_date(self.date_input.text)
        except ValueError as e:self.show_popup('Invalid date',str(e)); return
        target=self.path_for_date(d); self.loaded_file=target; self.records=self.read_csv_file(target); self.current_record=0 if self.records else -1
        if self.records:self.show_record()
        else:self.category_spinner.text='Select Category'; self.ntype_label.text=''; self.desc_input.text=''; self.amount_input.text=''; self.record_label.text='0 / 0'
        self.file_label.text='CSV: '+os.path.basename(target); self.refresh_totals()
    def save_all_records(self,i):
        try:d=self.normalize_date(self.date_input.text)
        except ValueError as e:self.show_popup('Invalid date',str(e)); return
        target=self.path_for_date(d)
        if self.loaded_file and os.path.abspath(self.loaded_file)!=os.path.abspath(target): self.write_csv_file(self.loaded_file,self.records); self.records=self.read_csv_file(target)
        self.loaded_file=target; self.write_csv_file(target,self.records); self.file_label.text='CSV: '+os.path.basename(target); self.refresh_totals(); self.show_popup('Saved',f'{len(self.records)} record(s) saved to\n{os.path.basename(target)}')
    def refresh_totals(self):
        total=0; mentions=defaultdict(float)
        for r in self.records:
            try:a=float(r.get('Amount',0))
            except (TypeError,ValueError):a=0
            total+=a
            for m in self.extract_mentions(r.get('Description','')):mentions[m]+=a
        self.total_label.text=f'₹ {total:,.2f}'
        self.mention_label.text='\n'.join(f'[b]{m}[/b] : ₹ {v:,.2f}' for m,v in sorted(mentions.items(),key=lambda x:x[0].casefold())) if mentions else 'No mentions'

class ExpenseApp(App):
    def build(self): self.title='Expense Tracker'; return MainLayout()
if __name__=='__main__': ExpenseApp().run()
