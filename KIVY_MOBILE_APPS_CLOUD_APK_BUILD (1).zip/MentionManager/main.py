from pathlib import Path
import re
import os

import yaml
from kivy.app import App
from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.image import Image
from kivy.uix.textinput import TextInput
from kivy.uix.scrollview import ScrollView
from kivy.uix.popup import Popup


DEFAULT_MENTIONS = [
    "@rabbi",
    "@sbi",
    "@ebay",
    "@Amazon",
    "@flipkart",
    "@swiggy",
    "@zomato",
]

MENTION_RE = re.compile(r"^@[A-Za-z0-9_][A-Za-z0-9_.-]*$")


class MentionStore:
    """YAML persistence for the Finance Manager @mention list."""

    def __init__(self, path=None):
        self.path = Path(path or "mentions.yaml")
        self.mentions = []
        self.load()

    @staticmethod
    def normalize(value):
        value = value.strip()
        if not value:
            return ""
        if not value.startswith("@"):
            value = "@" + value
        return value

    def load(self):
        if not self.path.exists():
            self.mentions = list(DEFAULT_MENTIONS)
            self.save()
            return

        try:
            with self.path.open("r", encoding="utf-8") as fh:
                data = yaml.safe_load(fh) or {}

            raw = data.get("mentions", [])
            if not isinstance(raw, list):
                raise ValueError("mentions must be a YAML list")

            result = []
            seen = set()
            for item in raw:
                mention = self.normalize(str(item))
                key = mention.casefold()
                if mention and key not in seen and MENTION_RE.match(mention):
                    result.append(mention)
                    seen.add(key)

            self.mentions = result
        except Exception:
            # Preserve a usable application even if the YAML is malformed.
            self.mentions = list(DEFAULT_MENTIONS)

    def save(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        payload = {"mentions": sorted(self.mentions, key=str.casefold)}
        with self.path.open("w", encoding="utf-8") as fh:
            yaml.safe_dump(
                payload,
                fh,
                allow_unicode=True,
                sort_keys=False,
                default_flow_style=False,
            )

    def add(self, value):
        mention = self.normalize(value)
        if not MENTION_RE.match(mention):
            raise ValueError(
                "Use @ followed by letters, numbers, _, . or -. "
                "Example: @Amazon"
            )
        if any(x.casefold() == mention.casefold() for x in self.mentions):
            raise ValueError("That mention already exists.")
        self.mentions.append(mention)
        return mention

    def update(self, old, new):
        mention = self.normalize(new)
        if not MENTION_RE.match(mention):
            raise ValueError("Invalid mention format.")
        for i, existing in enumerate(self.mentions):
            if existing.casefold() == old.casefold():
                duplicate = any(
                    j != i and x.casefold() == mention.casefold()
                    for j, x in enumerate(self.mentions)
                )
                if duplicate:
                    raise ValueError("That mention already exists.")
                self.mentions[i] = mention
                return mention
        raise ValueError("Mention no longer exists.")

    def delete(self, mention):
        self.mentions = [
            x for x in self.mentions
            if x.casefold() != mention.casefold()
        ]


class MentionRow(BoxLayout):
    def __init__(self, mention, edit_callback, delete_callback, **kwargs):
        super().__init__(
            orientation="horizontal",
            spacing=dp(8),
            padding=(dp(8), dp(5)),
            size_hint_y=None,
            height=dp(52),
            **kwargs,
        )

        label = Label(
            text=mention,
            halign="left",
            valign="middle",
            font_size="18sp",
        )
        label.bind(size=lambda inst, val: setattr(inst, "text_size", val))
        self.add_widget(label)

        edit = Button(text="Edit", size_hint_x=None, width=dp(72))
        edit.bind(on_release=lambda *_: edit_callback(mention))
        self.add_widget(edit)

        delete = Button(text="Delete", size_hint_x=None, width=dp(82))
        delete.bind(on_release=lambda *_: delete_callback(mention))
        self.add_widget(delete)


class MentionManagerApp(App):
    def build_logo_header(self, title_text, subtitle_text=""):
        header = BoxLayout(orientation="horizontal", size_hint_y=None, height=dp(82), spacing=dp(10))
        logo_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets", "finance_logo.png")
        if os.path.exists(logo_path):
            header.add_widget(Image(source=logo_path, size_hint=(None, 1), width=dp(70), keep_ratio=True, allow_stretch=True))
        text_box = BoxLayout(orientation="vertical", spacing=dp(1))
        text_box.add_widget(Label(text=title_text, markup=True, font_size="24sp", bold=True, halign="left", valign="middle"))
        if subtitle_text:
            text_box.add_widget(Label(text=subtitle_text, font_size="12sp", halign="left", valign="middle"))
        header.add_widget(text_box)
        return header

    title = "Mention Manager"

    def build(self):
        self.store = MentionStore(
            Path(self.user_data_dir) / "mentions.yaml"
        )

        # Keep the application's YAML portable and easy to find.
        # The user can replace this with a project-local path if desired.
        self.yaml_path = Path(self.user_data_dir) / "mentions.yaml"

        root = BoxLayout(
            orientation="vertical",
            padding=dp(12),
            spacing=dp(10),
        )

        header = self.build_logo_header(
            "[b]@ Mention Manager[/b]",
            "Manage mentions.yaml",
        )
        self.path_label = Label(
            text=f"Saved to: {self.yaml_path}",
            font_size="12sp",
            shorten=True,
            shorten_from="right",
        )
        header.add_widget(self.path_label)
        root.add_widget(header)

        form = GridLayout(
            cols=2,
            size_hint_y=None,
            height=dp(58),
            spacing=dp(8),
        )
        self.input = TextInput(
            hint_text="Enter mention, e.g. @Amazon",
            multiline=False,
            font_size="18sp",
        )
        self.input.bind(on_text_validate=lambda *_: self.add_mention())
        form.add_widget(self.input)

        add_btn = Button(text="Add", size_hint_x=None, width=dp(100))
        add_btn.bind(on_release=lambda *_: self.add_mention())
        form.add_widget(add_btn)
        root.add_widget(form)

        self.status = Label(
            text="",
            size_hint_y=None,
            height=dp(30),
            font_size="14sp",
        )
        root.add_widget(self.status)

        self.scroll = ScrollView()
        self.list_box = GridLayout(
            cols=1,
            spacing=dp(4),
            size_hint_y=None,
        )
        self.list_box.bind(
            minimum_height=self.list_box.setter("height")
        )
        self.scroll.add_widget(self.list_box)
        root.add_widget(self.scroll)

        bottom = BoxLayout(
            size_hint_y=None,
            height=dp(52),
            spacing=dp(8),
        )

        save_btn = Button(text="Save YAML")
        save_btn.bind(on_release=lambda *_: self.save_yaml())
        bottom.add_widget(save_btn)

        reload_btn = Button(text="Reload")
        reload_btn.bind(on_release=lambda *_: self.reload_yaml())
        bottom.add_widget(reload_btn)

        root.add_widget(bottom)

        self.refresh_list()
        return root

    def set_status(self, text):
        self.status.text = text

    def refresh_list(self):
        self.list_box.clear_widgets()
        for mention in sorted(self.store.mentions, key=str.casefold):
            self.list_box.add_widget(
                MentionRow(
                    mention,
                    self.edit_mention,
                    self.confirm_delete,
                )
            )
        self.set_status(f"{len(self.store.mentions)} mentions")

    def add_mention(self):
        try:
            mention = self.store.add(self.input.text)
            self.input.text = ""
            self.store.save()
            self.refresh_list()
            self.set_status(f"Added {mention}")
        except ValueError as exc:
            self.show_message("Cannot add mention", str(exc))

    def edit_mention(self, old):
        content = BoxLayout(
            orientation="vertical",
            padding=dp(12),
            spacing=dp(10),
        )

        field = TextInput(
            text=old,
            multiline=False,
            font_size="18sp",
        )
        content.add_widget(field)

        buttons = BoxLayout(
            size_hint_y=None,
            height=dp(48),
            spacing=dp(8),
        )
        content.add_widget(buttons)

        popup = Popup(
            title=f"Edit {old}",
            content=content,
            size_hint=(0.9, None),
            height=dp(190),
        )

        cancel = Button(text="Cancel")
        cancel.bind(on_release=popup.dismiss)
        buttons.add_widget(cancel)

        save = Button(text="Save")
        def do_save(*_):
            try:
                new = self.store.update(old, field.text)
                self.store.save()
                self.refresh_list()
                self.set_status(f"Updated to {new}")
                popup.dismiss()
            except ValueError as exc:
                self.show_message("Cannot update mention", str(exc))

        save.bind(on_release=do_save)
        buttons.add_widget(save)

        popup.open()

    def confirm_delete(self, mention):
        content = BoxLayout(
            orientation="vertical",
            padding=dp(12),
            spacing=dp(10),
        )
        content.add_widget(Label(
            text=f"Delete {mention}?",
            font_size="18sp",
        ))

        buttons = BoxLayout(
            size_hint_y=None,
            height=dp(48),
            spacing=dp(8),
        )
        content.add_widget(buttons)

        popup = Popup(
            title="Confirm delete",
            content=content,
            size_hint=(0.85, None),
            height=dp(170),
        )

        cancel = Button(text="Cancel")
        cancel.bind(on_release=popup.dismiss)
        buttons.add_widget(cancel)

        delete = Button(text="Delete")
        def do_delete(*_):
            self.store.delete(mention)
            self.store.save()
            self.refresh_list()
            self.set_status(f"Deleted {mention}")
            popup.dismiss()

        delete.bind(on_release=do_delete)
        buttons.add_widget(delete)

        popup.open()

    def save_yaml(self):
        try:
            self.store.save()
            self.set_status(f"Saved {len(self.store.mentions)} mentions")
        except Exception as exc:
            self.show_message("Save failed", str(exc))

    def reload_yaml(self):
        self.store.load()
        self.refresh_list()
        self.set_status("Reloaded mentions.yaml")

    def show_message(self, title, message):
        content = BoxLayout(
            orientation="vertical",
            padding=dp(12),
            spacing=dp(10),
        )
        content.add_widget(Label(text=message))
        close = Button(
            text="OK",
            size_hint_y=None,
            height=dp(46),
        )
        content.add_widget(close)

        popup = Popup(
            title=title,
            content=content,
            size_hint=(0.9, None),
            height=dp(190),
        )
        close.bind(on_release=popup.dismiss)
        popup.open()


if __name__ == "__main__":
    MentionManagerApp().run()
