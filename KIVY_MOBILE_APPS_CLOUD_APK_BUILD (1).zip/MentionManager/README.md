# @ Mention Manager — Kivy

A small, runnable Python/Kivy mobile application for maintaining the
`@mention` list used by the Finance Manager application.

## Features

- Add mentions
- Edit mentions
- Delete mentions
- Save/load YAML
- Duplicate prevention
- Automatic `@` normalization
- Validation
- Preloaded examples
- Mobile-friendly Kivy layout

## Preloaded mentions

- @rabbi
- @sbi
- @ebay
- @Amazon
- @flipkart
- @swiggy
- @zomato

## Run on desktop

Create a virtual environment, then:

```bash
pip install -r requirements.txt
python main.py
```

The app creates/uses a YAML file in Kivy's application data directory.

## YAML format

```yaml
mentions:
  - "@rabbi"
  - "@sbi"
  - "@ebay"
  - "@Amazon"
```

## Android

For Android packaging, Buildozer can be used from Linux/WSL.

Typical first setup:

```bash
pip install buildozer
buildozer init
```

Then configure the generated `buildozer.spec` so that the requirements include:

```text
python3,kivy,pyyaml
```

Build/debug:

```bash
buildozer android debug
```

Install the generated APK on an Android device.

## Finance Manager integration

The resulting YAML has the same logical structure expected by the
Finance Manager mention loader:

```python
with open("mentions.yaml", "r", encoding="utf-8") as fh:
    data = yaml.safe_load(fh) or {}

mentions = data.get("mentions", [])
```

For the main Finance Manager project, the persistence path can be changed
to the shared application's `mentions.yaml` location.
