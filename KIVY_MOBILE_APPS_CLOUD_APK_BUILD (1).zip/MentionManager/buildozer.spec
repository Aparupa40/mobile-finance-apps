[app]
title = Mention Manager
package.name = mentionmanager
package.domain = org.financemanager
source.dir = .
source.include_exts = py,png,jpg,jpeg,yaml,yml,md,txt,kv,atlas
version = 1.0.2
requirements = python3,kivy,pyyaml
orientation = portrait
fullscreen = 0

android.api = 33
android.minapi = 21
android.archs = arm64-v8a, armeabi-v7a

[buildozer]
log_level = 2
warn_on_root = 1
