# Cloud APK Build

Upload this package to a GitHub repository and run **Build Kivy Android APKs** under Actions.
The workflow performs real `buildozer android debug` builds for MentionManager and ExpenseTracker
and uploads the resulting APKs as workflow artifacts.

Git is only the source-control/hosting mechanism. Buildozer is the Kivy Android packaging tool.
No APK is claimed to have been built inside this runtime.
